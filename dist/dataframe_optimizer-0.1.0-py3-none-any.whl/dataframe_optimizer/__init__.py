"""
Dataframe Optimizer

A Python package that give utils to optimize Pandas dataframes
"""

from .main import optimize_dataframe

__version__ = "0.1.0"
__author__ = 'Quentin Rospars'
__credits__ = 'Quentin Rospars'
